
<div class="alert alert-success m-4" align="center">
	Selamat Pesanan Berhasil Di Proses!!
	<br><br>
	<a class="btn btn-sm btn-primary" href="<?php base_url()?>/restoran/">Home</a>
</div>